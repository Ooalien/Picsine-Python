from setuptools import setup

setup(
    name="ft_package",
    version='0.0.1',
    Summary="A sample test package",
    Home_page="https://github.com/Ooalien/my_first_pythonPackage.git",
    author="abayar",
    author_email="abayar@student.1337.ma",
    Licence="MIT",
    Requires=[],
    Required_by="",
    Metadata_Version="2.1",
    Installer="pip",
    classifiers=[],
    Entry_points={},
)