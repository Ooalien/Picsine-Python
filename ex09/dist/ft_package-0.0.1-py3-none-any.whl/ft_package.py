#this function returns the number of times the item is in the list
def count_in_list(list, item):
    return list.count(item)